<div id="footer">
            <h2>Rudnev Danil      danil.160398@yandex.ru</h2>
            <h2>Rostov-on-Don</h2>
            <h2>2017</h2>
        </div>
    </body>
</html>
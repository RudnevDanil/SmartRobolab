<?php
    //Запускаем сессию
    session_start();
    //Добавляем файл подключения к БД
    require_once("dbconnect.php");
    //if(isset($_POST["button_1_click"]))
    //Работа если нажали кнопку
    $date_now = date("Y-m-d H:i:s");
    if(isset($_POST["nom_last_but"])) $nom_but = $_POST["nom_last_but"];
    else $nom_but = 0;
    $nom_but = htmlspecialchars($nom_but, ENT_QUOTES);//Не знаю на сколько необходимо, и без этого работает на этом этапе, но пусть будет
    //Запрос на обращение к БД
    $result_query_insert = $mysqli->query("INSERT INTO `buttons_log` (nom_but,date) VALUES ('".$nom_but."', '".$date_now."')");
    //Закрываем подключение к БД
    $mysqli->close();
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: ".$address_site."/index.php");  
    //Останавливаем  скрипт
    exit();
?>




<div id="buttons" style="text-align: center;">
    <form method="post" id="send_button" action="" >
        
        <input type="button" id="MOVE" value="MOVE" />
        <input type="button" id="STOP" value="STOP" />
        
        
    </form>
    <!-- Для добавления новых кнопок :
            1) добавить кнопку с уникальным id в форму
            2) в файле ajax.js внести изменения
                2.1) #тут id кнопки
                2.2) третий аргумент функции - то что запишется в базу как номер команды
    -->
</div>
    